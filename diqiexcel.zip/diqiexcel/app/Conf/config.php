<?php
// +----------------------------------------------------------------------
// | Description: Be yourself
// +----------------------------------------------------------------------
// | Copyright (c) 2012-2014 http://www.bbw712.com All rights reserved.
// +----------------------------------------------------------------------
// | Author: simon wsyone@foxmail.com
// +----------------------------------------------------------------------
// | Date:2014-5-17
return array(
	//'配置项'=>'配置值'
	'SHOW_PAGE_TRACE'=>true,
	'URL_HTML_SUFFIX'=>'.html',
	'DB_TYPE' => 'mysql',
	  'DB_HOST' => 'localhost',
	  'DB_NAME' => 'dq_info',
	  'DB_USER' => 'root',//用户
	  'DB_PWD' => '',//密码
	  'DB_PORT' => '3306',
	  'DB_PREFIX' =>  'dq_',
);

