<?php
// +----------------------------------------------------------------------
// | Description: Be yourself
// +----------------------------------------------------------------------
// | Copyright (c) 2012-2014 http://www.bbw712.com All rights reserved.
// +----------------------------------------------------------------------
// | Author: simon wsyone@foxmail.com   
// +----------------------------------------------------------------------
// | Date:2014-5-17 
define('APP_DEBUG',true);
define('APP_NAME','excel');
define('APP_PATH','./app/');
define('ENGINE_NAME','cluster');
include('./ThinkPHP/ThinkPHP.php');
?>