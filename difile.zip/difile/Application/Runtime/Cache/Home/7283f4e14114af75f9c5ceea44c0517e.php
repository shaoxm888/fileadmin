<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>TODO supply a title</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body>
<form method="post" action="php文件" enctype="multipart/form-data">
 <h3>导入Excel表：</h3><input type="file" name="file_stu" />

 <input type="submit" value="导入" />
</form>

    </body>
</html>